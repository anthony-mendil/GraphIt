package gui.properties;

/**
 * javadocTODO
 */
public enum Language {
    /**
     * javadocTODO
     */
    GERMAN,
    /**
     * javadocTODO
     */
    ENGLISH
}
