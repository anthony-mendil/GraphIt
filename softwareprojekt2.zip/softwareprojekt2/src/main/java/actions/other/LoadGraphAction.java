package actions.other;

import actions.GraphAction;

/**
 * Loads the existing graph to syndrom.
 */
public class LoadGraphAction extends GraphAction {
    /**
     * Loads an existing graph from a file to syndrom.
     */
    public LoadGraphAction() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void action() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void undo() {
        throw new UnsupportedOperationException();
    }
}
