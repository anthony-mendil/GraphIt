package actions.analyse;

import actions.GraphAction;

/**
 * Displays some useful data in matter of the dimension of the graph (scope, networking index, structural index). The
 * information is displayed in the gui.
 */
public class GraphDimensionAction extends GraphAction {
    /**
     * Computes the data needed for the current graph.
     */
    public GraphDimensionAction() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void action() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void undo() {
        throw new UnsupportedOperationException();
    }
}
