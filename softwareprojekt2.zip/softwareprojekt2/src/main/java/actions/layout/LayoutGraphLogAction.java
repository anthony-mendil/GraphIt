package actions.layout;

import actions.LogAction;
import actions.LogEntryName;
import log_management.parameters.move.LayoutParam;

/**
 * Layouts the graph according to a previously defined layout.
 */
public class LayoutGraphLogAction extends LogAction {

    /**
     * Layouts the graph (including all vertices) according to the defined layout.
     */
    public LayoutGraphLogAction() {
        super(LogEntryName.EDIT_LAYOUT);
        throw new UnsupportedOperationException();
    }

    @Override
    public void createParameter() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void action() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void undo() {
        throw new UnsupportedOperationException();
    }
}
