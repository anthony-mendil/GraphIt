Geändert: 
    - GraphDao hat currentId
    - PersonalEntityManager hinzugefügt: Singleton für EntitiyManager
    - In Log Attribut graphId (int) durch graph (Graph)
    - Klasse GraphAndLogId entfernt (nur noch ein graph grap in graph graph tabelle :))
    - bei Graph Attribut gxl (String) hinzugefügt inklusive Getter und Setter 
   